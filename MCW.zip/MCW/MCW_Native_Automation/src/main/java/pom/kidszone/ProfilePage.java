package pom.kidszone;

import com.reusableMethods.CommonActions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class ProfilePage extends CommonActions {

    public static final Logger logger = LoggerFactory.getLogger(BuyPage.class);
    //*********************************Locator********************************************//
    @AndroidFindBy(xpath = "//android.widget.Button[@index='5']")
    public MobileElement click_profileBtn;
    @AndroidFindBy(xpath = "//android.widget.ImageView[@index='0']")
    public List<MobileElement> validate_imagesAndElements;
    @AndroidFindBy(xpath = "//*[@text='Account']")
    public MobileElement verify_accountTxt;
    @AndroidFindBy(xpath = "//*[@text='Create an account !']")
    public MobileElement verify_createAccountTxt;
    @AndroidFindBy(xpath = "//android.widget.Button[@index='2']")
    public MobileElement verify_createAccountBtn;
    @AndroidFindBy(xpath = "//*[@text='Already have an account 1 ']")
    public MobileElement verify_alreadyAccountTxt;
    @AndroidFindBy(xpath = "//*[@text='Login !']")
    public MobileElement verify_loginTxt;

    public ProfilePage(AppiumDriver driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    //*********************************Methods********************************************//
    public void userShouldClickOnProfileButton() {
        waitFor(3000);
        ClickOnMobileElement(click_profileBtn);
        waitFor(5000);
    }

    public void userShouldVerifyButtonHamburgerMenuLinkLocationIcon() {
        for (WebElement allElements : validate_imagesAndElements) {
            waitFor(10000);
            Assert.assertTrue(isElementPresent(allElements));
        }
    }

    public void userShouldVerifyHeaderText() {
        String headerTxt = verify_accountTxt.getText();
        Assert.assertEquals(headerTxt, "Account");
    }

    public void userShouldVerifyCreateAccountButtonAndText() {
        Assert.assertTrue(isElementPresent(verify_createAccountBtn));
        String headerTxt = verify_createAccountTxt.getText();
        Assert.assertEquals(headerTxt, "Create an account !");
    }

    public void userShouldVerifyAlreadyHaveAnAccountText() {
        String headerTxt = verify_alreadyAccountTxt.getText();
        Assert.assertEquals(headerTxt, "Already have an account 1 ");
    }

    public void userShouldVerifyLoginText() {
        String headerTxt = verify_loginTxt.getText();
        Assert.assertEquals(headerTxt, "Login !");
    }
}
