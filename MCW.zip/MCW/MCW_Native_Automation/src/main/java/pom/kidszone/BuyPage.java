package pom.kidszone;

import com.reusableMethods.CommonActions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class BuyPage extends CommonActions {

    public static final Logger logger = LoggerFactory.getLogger(BuyPage.class);

    public BuyPage(AppiumDriver driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }


    //*********************************Locator********************************************//
    @AndroidFindBy(xpath = "//android.widget.Button[@index='3']")
    public MobileElement click_buyBtn;
    @AndroidFindBy(xpath = "//android.widget.ImageView[@index='0'] ")
    public List<MobileElement> validate_imagesAndElements;
    @AndroidFindBy(xpath = "//*[@text='Discover']")
    public MobileElement verify_headerTxt;
    @AndroidFindBy(xpath = "//*[@text='Join UNLIMITED Wash Club®']")
    public MobileElement verify_planTxt;
    @AndroidFindBy(xpath = "//*[@text='Buy A Wash']")
    public MobileElement verify_washTxt;
    @AndroidFindBy(xpath = "//*[@text='Description goes here']")
    public MobileElement verify_washContentTxt;
    @AndroidFindBy(xpath = "//*[@text='Description goes here']")
    public MobileElement verify_planContentTxt;

    //*********************************Methods********************************************//

    public void userShouldClickOnBuyPageButton() {
        waitFor(3000);
        ClickOnMobileElement(click_buyBtn);
        waitFor(5000);
    }

    public void userShouldVerifyHamburgerMenuAndLocationIconAndAllImagesOfBuyPage() {
        //Validate buttons,hamburger icon,location,images
        for (WebElement allElements : validate_imagesAndElements) {
            waitFor(10000);
            Assert.assertTrue(isElementPresent(allElements));
        }
    }

    public void userShouldVerifyTitleOfThePage() {
        String headerTxt = verify_headerTxt.getText();
        Assert.assertEquals(headerTxt, "Discover");
    }

    public void userShouldVerifyWashTitleAndPlanTitle() {
        String planTxt = verify_planTxt.getText();
        Assert.assertEquals(planTxt, "Join UNLIMITED Wash Club®");
        String washTxt = verify_washTxt.getText();
        Assert.assertEquals(washTxt, "Buy A Wash");
    }

    public void userShouldVerifyDescriptionTitles() {
        Assert.assertTrue(isElementPresent(verify_washContentTxt));
        Assert.assertTrue(isElementPresent(verify_planContentTxt));
    }
}
