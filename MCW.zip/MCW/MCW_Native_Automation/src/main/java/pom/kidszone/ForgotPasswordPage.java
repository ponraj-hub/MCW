package pom.kidszone;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.*;
import java.awt.event.KeyEvent;

public class ForgotPasswordPage extends CommonActions {

    public static final Logger logger = LoggerFactory.getLogger(HomePage.class);
    //*********************************Locator********************************************//
    @AndroidFindBy(accessibility = "Forgot Password")
    public MobileElement verify_forgotPwd;
    @AndroidFindBy(accessibility = "Forgot Password ")
    public MobileElement verify_forgotPwdHeaderText;

    @AndroidFindBy(accessibility = "Need to reset your password? Verify your account with a six digit passcode to start.")
    public MobileElement verify_forgotPwdContentTxt;

    @AndroidFindBy(accessibility = "Use My Email ")
    public MobileElement verify_useMyEmail;

    @AndroidFindBy(accessibility = "Email, ")
    public MobileElement verify_emailBox;
    @AndroidFindBy(accessibility = "Send Code , dobule tap to send the code")
    public MobileElement verify_sendCodeBtn;

    public ForgotPasswordPage(AppiumDriver driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    //*********************************Methods********************************************//

    public void userShouldVerifyForgotPasswordLinkAndClickOnForgotPasswordLink() {
        ClickOnMobileElement(verify_forgotPwd);
        String forgotPwdHeaderTxt = verify_forgotPwdHeaderText.getText();
        Assert.assertEquals(forgotPwdHeaderTxt, "Forgot Password ");
    }

    public void userShouldVerifyForgotPasswordContent() {
        Assert.assertTrue(isElementPresent(verify_forgotPwdContentTxt));
        String content=verify_forgotPwdContentTxt.getText();
        Assert.assertEquals(content,"Need to reset your password? Verify your account with a six digit passcode to start.");
    }

    public void userShouldVerifyUseMyEmailText() {
       String emailTitle=verify_useMyEmail.getText();
       Assert.assertEquals(emailTitle,"Use My Email ");
    }

    public void userShouldVerifyEmailTextBox() throws AWTException {
        Assert.assertTrue(isElementPresent(verify_emailBox));
        ClickOnMobileElement(verify_emailBox);
        SendKeysOnMobileElement(verify_emailBox,"ponraj8785+qa@gmail.com");
        waitFor(2000);
    }

    public void userShouldVerifySendCodeButton() {
         Assert.assertTrue(isElementPresent(verify_sendCodeBtn));
         ClickOnMobileElement(verify_sendCodeBtn);
         waitFor(10000);
    }
}
