package pom.kidszone;

import com.reusableMethods.CommonActions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class HomePage extends CommonActions {

    public static final Logger logger = LoggerFactory.getLogger(HomePage.class);

    //*********************************Locator********************************************//
    @AndroidFindBy(accessibility = "Mister Car Wash Logo")
    public MobileElement verify_MisterLogo;
    @AndroidFindBy(xpath = "//android.widget.ImageView[@index='0'][1]")
    public MobileElement verify_HamburgerMenu;
    @AndroidFindBy(xpath = "//android.widget.ImageView[@index='1']")
    public MobileElement verify_homeTextInHamburgerMenu;
    @AndroidFindBy(xpath = "//android.widget.ImageView[@index='0']")
    public MobileElement verify_locationIconInHamburgerMenu;
    @AndroidFindBy(xpath = "//android.view.View[@index='0']")
    public MobileElement verify_closeIconInHamburgerMenu;
    @AndroidFindBy(xpath = "//android.widget.TextView[@index='0']")
    public List<MobileElement> verify_hamburgerMenuLinks;
    @AndroidFindBy(xpath = "//android.widget.TextView[@index='1']")
    public MobileElement verify_headerPopup;
    @AndroidFindBy(xpath = "//*[@text='While using the app']")
    public MobileElement verify_whileUsingTxt;
    @AndroidFindBy(xpath = "//*[@text='Only this time']")
    public MobileElement verify_onlyThisTxt;
    @AndroidFindBy(xpath = "//*[@text='Deny']")
    public MobileElement verify_denyTxt;
    @AndroidFindBy(xpath = "//android.widget.ImageView[@index='0']")
    public MobileElement verify_promoSectionImage;
    @AndroidFindBy(xpath = "//*[@text='Promo Section CTA !']")
    public MobileElement verify_ctaBtn;
    @AndroidFindBy(xpath = "//*[@text='Promo Section Title here !']")
    public MobileElement verify_titleTxt;
    @AndroidFindBy(xpath = "//*[@text='Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum !']")
    public MobileElement verify_txtContent;
    @AndroidFindBy(xpath = "//*[@text='Nearest Locations']")
    public MobileElement verify_nearestLocationTxt;
    @AndroidFindBy(xpath = "//*[@text='Use My Location']")
    public MobileElement verify_useMyLocationLnk;
    @AndroidFindBy(accessibility = "and double tap to navigate to buy a uwc plan list page")
    public MobileElement verify_uwcBtn;
    @AndroidFindBy(accessibility = "and double tap to navigate to buy a wash list page")
    public MobileElement verify_washBtn;
    @AndroidFindBy(accessibility = "and double tap to go to login page")
    public MobileElement verify_alreadyMemberBtn;
    @AndroidFindBy(accessibility = "and double tap to navigate to location page")
    public MobileElement verify_locationBtn;
    @AndroidFindBy(xpath = "//android.widget.Button[@index='1']")
    public MobileElement verify_homeBtn;
    @AndroidFindBy(xpath = "//android.widget.Button[@index='3']")
    public MobileElement verify_buyBtn;
    @AndroidFindBy(xpath = "//android.widget.Button[@index='5']")
    public MobileElement verify_profileBtn;

    public HomePage(AppiumDriver driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }


    //*********************************Methods********************************************//
    public void userShouldVerifyMisterLogo() {
        logger.info("Verify Mister Logo Image");
        Assert.assertTrue(isElementPresent(verify_MisterLogo));
    }

    public void userShouldVerifyHamburgerMenuAndValidateThePage() {
        logger.info("Verify HamburgerMenu And Their links");
        waitFor(2000);
        Assert.assertTrue(isElementPresent(verify_HamburgerMenu));
        ClickOnMobileElement(verify_HamburgerMenu);
        Assert.assertTrue(isElementPresent(verify_homeTextInHamburgerMenu));
        Assert.assertTrue(isElementPresent(verify_locationIconInHamburgerMenu));
        Assert.assertTrue(isElementPresent(verify_closeIconInHamburgerMenu));
        ClickOnMobileElement(verify_closeIconInHamburgerMenu);
        waitFor(2000);
    }

    public void userShouldVerifyLocationIconAndValidateThePageAsGuest() {
        logger.info("Verify Location Icon");
        Assert.assertTrue(isElementPresent(verify_locationIconInHamburgerMenu));
    }

    public void userShouldVerifyTheLinksInsideTheHamburgerMenu() {
        logger.info("Verify Hamburger Menu links");
        for (WebElement links : verify_hamburgerMenuLinks) {
            System.out.println("Total no of links " + links);
            Assert.assertTrue(isElementPresent(links));
        }
    }

    public void userShouldVerifyLocationPagePopupNotification() {
        logger.info("Verify Location Page PopUp Notification");
        ClickOnMobileElement(verify_locationIconInHamburgerMenu);
        Assert.assertTrue(isElementPresent(verify_headerPopup));
        String firstTxt = verify_whileUsingTxt.getText();
        Assert.assertEquals(firstTxt, "While using the app");
        String secondTxt = verify_onlyThisTxt.getText();
        Assert.assertEquals(secondTxt, "Only this time");
        String thirdTxt = verify_denyTxt.getText();
        Assert.assertEquals(thirdTxt, "Deny");
        ClickOnMobileElement(verify_denyTxt);
    }

    public void userShouldVerifyPromoSectionInTheHomePage() {
        logger.info("Verify Promo Section Image");
        Assert.assertTrue(isElementPresent(verify_promoSectionImage));
    }

    public void userShouldVerifyCtaButtonAndTextsInThePromoSection() {
        logger.info("Verify CTA Button And Text In the Promo Section");
        Assert.assertTrue(isElementPresent(verify_ctaBtn));
        String titleText = verify_titleTxt.getText();
        Assert.assertEquals(titleText, "Promo Section Title here !");
        String contentText = verify_txtContent.getText();
        Assert.assertEquals(contentText, "Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum !");

    }

    public void userShouldVerifyNearestLocationTextAndUseMyLocationLink() {
        logger.info("Verify Nearest Location Text And Link");
        String nearestLocation = verify_nearestLocationTxt.getText();
        Assert.assertEquals(nearestLocation, "Nearest Locations");
        String useMyLocation = verify_useMyLocationLnk.getText();
        Assert.assertEquals(useMyLocation, "Use My Location");
    }

    public void userShouldVerifyUwcWashAlreadyMemberLocatorButtons() {
        logger.info("Verify Home Page Buttons");
        Assert.assertTrue(isElementPresent(verify_uwcBtn));
        Assert.assertTrue(isElementPresent(verify_washBtn));
        Assert.assertTrue(isElementPresent(verify_alreadyMemberBtn));
        Assert.assertTrue(isElementPresent(verify_locationBtn));
    }

    public void userShouldVerifyHomeBuyProfileButtonOnHomePage() {
        logger.info("Verify Home Buy Profile Page Buttons");
        Assert.assertTrue(isElementPresent(verify_homeBtn));
        boolean verifyHomeEnabled = verify_homeBtn.isEnabled();
        Assert.assertTrue(verifyHomeEnabled);
        Assert.assertTrue(isElementPresent(verify_buyBtn));
        Assert.assertTrue(isElementPresent(verify_profileBtn));
    }
}