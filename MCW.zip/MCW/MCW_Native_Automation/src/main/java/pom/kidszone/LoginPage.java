package pom.kidszone;

import com.reusableMethods.CommonActions;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class LoginPage extends CommonActions {

    public static final Logger logger = LoggerFactory.getLogger(LoginPage.class);
    // *********************************Locator********************************************//
    @AndroidFindBy(xpath = "//*[@text='Login !']")
    public MobileElement click_loginLnk;
    @AndroidFindBy(accessibility = "Back, and double tap to go back")
    public MobileElement verify_backArrowBtn;
    @AndroidFindBy(xpath = "//*[@text='Login']")
    public List<MobileElement> verify_loginTxt;
    //back arrow ,location icon,mister image, splash ,remember me check box
    @AndroidFindBy(xpath = "//android.widget.ImageView[@index='0']")
    public List<MobileElement> verify_loginPageElements;
    @AndroidFindBy(accessibility = "Email, ")
    public MobileElement verify_emailBox;
    @AndroidFindBy(accessibility = "Password, ")
    public MobileElement verify_passwordBox;
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Remember me']")
    public MobileElement verify_rememberMeText;
    @AndroidFindBy(accessibility = "Forgot Password")
    public MobileElement verify_forgotPwd;
    @AndroidFindBy(accessibility = "Forgot Password ")
    public MobileElement verify_forgotPwdHeaderText;
    @AndroidFindBy(xpath = "//android.widget.ImageView[@index='0']")
    public MobileElement click_closeBtn;
    @AndroidFindBy(xpath = "//android.widget.TextView[@index='0']")
    public MobileElement verify_dontHaveAnAccount;
    @AndroidFindBy(xpath = "//android.widget.TextView[@index='0']")
    public MobileElement verify_createAccount;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[@index='4']")
    public MobileElement click_checkBox;

    public LoginPage(AppiumDriver driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    // *********************************Methods********************************************//

    public void userShouldClickOnLoginLink() {
        waitFor(2000);
        ClickOnMobileElement(click_loginLnk);
    }

    public void userShouldVerifyBackArrowButtonAndLocationIcon() {
        Assert.assertTrue(isElementPresent(verify_backArrowBtn));
    }

    public void userShouldVerifyLoginHeaderText() {
        for (WebElement loginTxt : verify_loginTxt) {
            waitFor(3000);
            String loginText = loginTxt.getText();
            Assert.assertEquals(loginText, "Login");
        }
    }

    public void userShouldVerifyMisterImageAndLoginImage() {
        for (WebElement loginPageElement : verify_loginPageElements) {
            waitFor(3000);
            Assert.assertTrue(isElementPresent(loginPageElement));
        }
    }

    public void userShouldVerifyEmailAndPasswordSearchBox() {
        Assert.assertTrue(isElementPresent(verify_emailBox));
        Assert.assertTrue(isElementPresent(verify_passwordBox));
    }

    public void userShouldVerifyRememberMeTextAndRememberMeCheckBox() {
        String rememberMeTxt = verify_rememberMeText.getText();
        Assert.assertEquals(rememberMeTxt, "Remember me");
    }

    public void userShouldVerifyForgotPasswordLink() {
        Assert.assertTrue(isElementPresent(verify_forgotPwd));
        ClickOnMobileElement(verify_forgotPwd);
        String forgotPwdHeaderTxt = verify_forgotPwdHeaderText.getText();
        Assert.assertEquals(forgotPwdHeaderTxt, "Forgot Password ");
        ClickOnMobileElement(click_closeBtn);
    }

    public void userShouldVerifyDontHaveAnAccountText() {
        Assert.assertTrue(isElementPresent(verify_dontHaveAnAccount));
    }

    public void userShouldVerifyCreateOneLink() {
        Assert.assertTrue(isElementPresent(verify_createAccount));
    }

    public void userShouldVerifyRememberMeCheckBox(){
       ClickOnMobileElement(click_checkBox);
       ClickOnMobileElement(click_checkBox);
    }
}
