package com.driverfactory.manager;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;

import com.driverfactory.DriverFactory.PlatformList;
import com.driverfactory.DriverFactory.Target;
import com.driverfactory.Factory;
import com.utilities.ConfigReader;

import exceptions.TargetNotValidException;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.MobileCapabilityType;

public class IOSDriverManager extends Factory {

	private DesiredCapabilities getOptions() throws IOException {
		DesiredCapabilities desiredCapabilities;
		desiredCapabilities = new DesiredCapabilities();
		desiredCapabilities.setCapability("platformName", "iOS");
		desiredCapabilities.setCapability("platformVersion", "15.4.1");
		desiredCapabilities.setCapability("deviceName", "iPhone 13");
		desiredCapabilities.setCapability("udid", "00008110-00142CEC1A78801E");
		desiredCapabilities.setCapability("bundleId", "com.photon.bnt.mobil.boundless");
		desiredCapabilities.setCapability("xcodeOrgId", "M72NAL3U5D");
		desiredCapabilities.setCapability("xcodeSigningId", "iPhone Developer");
		desiredCapabilities.setCapability("updatedWDABundleId", "com.photon.bnt.mobil.boundless");
		desiredCapabilities.setCapability("realMobile", "true");
		desiredCapabilities.setCapability("nativeWebTap","true");
//		desiredCapabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, ConfigReader.getData("iOSAutomationName"));
		desiredCapabilities.setCapability(MobileCapabilityType.APP, "/Users/sankarthirugnan/Downloads/KidsZone_title.ipa");
		return desiredCapabilities;
	}

	@SuppressWarnings("unchecked")
	@Override
	public IOSDriver<IOSElement> createIOSDriver(Target target) {
		switch (target) {
		case LOCAL:
			URL url = null;
			try {
				url = new URL("http://127.0.0.1:4723/wd/hub");
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			try {
				return new IOSDriver<IOSElement>(url, getOptions());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		case REMOTE:
			return (IOSDriver<IOSElement>) createRemoteDriver(PlatformList.IOS);
		default:
			throw new TargetNotValidException(target.toString());
		}
	}

}
