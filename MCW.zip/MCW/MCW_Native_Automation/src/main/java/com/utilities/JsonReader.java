package com.utilities;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JsonReader {
	public static final Logger logger = LoggerFactory.getLogger(JsonReader.class);
	JSONArray jsonarray;
	JSONObject environment;
	static JSONObject Obj;
	static JSONParser parser = new JSONParser();
	static JSONObject config = null;
	static String Library = null;
	static String env = null;

	public static JSONObject readJson() {

		try {

			config = (JSONObject) parser.parse(new FileReader("src/test/resources/config/TestData.json"));

		} catch (FileNotFoundException e) {
			e.printStackTrace();

		} catch (IOException e) {
			e.printStackTrace();

		} catch (ParseException e) {
			e.printStackTrace();

		}
		return config;

	}

	public static Map<String, String> readData() {
		readJson();
		env = System.getenv("ENVIRONMENT");
		if (env == null) {
			env = System.getProperty("Environment");

		}
		Library = System.getenv("LIBRARY");
		if (Library == null) {
			Library = System.getProperty("Library");

		}
		Map<String, String> map = new HashMap<String, String>();
		JSONArray envs = (JSONArray) config.get("environments");
		for (int i = 0; i < envs.size(); i++) {
			JSONObject environment = (JSONObject) envs.get(i);
			JSONArray jsonarray = (JSONArray) environment.get(env);
			for (int j = 0; j < jsonarray.size(); j++) {
				Obj = (JSONObject) jsonarray.get(j);
				if (nullEmptyBlankWithNull((String) Obj.get("library"))) {
					String libraryName = (String) Obj.get("library");
					String userName = (String) Obj.get("username");
					String password = (String) Obj.get("password");
					String feature = (String) Obj.get("feature");
					map.put("libraryName", libraryName);
					map.put("userName", userName);
					map.put("password", password);
					map.put("feature", feature);
				}

			}
		}
		return map;
	}

	public static boolean nullEmptyBlankWithNull(String passedStr) {
		if (passedStr != null && !passedStr.trim().isEmpty() && !passedStr.trim().equals("null")
				&& passedStr.equalsIgnoreCase(Library)) {
			return true;
		} else {
			return false;
		}
	}
}
