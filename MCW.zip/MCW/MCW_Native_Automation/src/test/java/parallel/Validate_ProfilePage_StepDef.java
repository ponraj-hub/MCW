package parallel;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.ProfilePage;

public class Validate_ProfilePage_StepDef extends CommonActions {

    ProfilePage profile = new ProfilePage(DriverManager.getDriver());

    @Given("user click on profile button")
    public void user_click_on_profile_button() {
        profile.userShouldClickOnProfileButton();
    }

    @When("user verify buttons,hamburger menu link,location icon")
    public void user_verify_buttons_hamburger_menu_link_location_icon() {
        profile.userShouldVerifyButtonHamburgerMenuLinkLocationIcon();
    }

    @Then("user verify header text")
    public void user_verify_header_text() {
        profile.userShouldVerifyHeaderText();
    }

    @Then("user verify create account button and text")
    public void user_verify_create_account_button_and_text() {
        profile.userShouldVerifyCreateAccountButtonAndText();
    }

    @Then("user verify login text")
    public void user_verify_login_text() {
        profile.userShouldVerifyLoginText();
    }

    @And("user verify already have an account text")
    public void userVerifyAlreadyHaveAnAccountText() {
        profile.userShouldVerifyAlreadyHaveAnAccountText();
    }
}
