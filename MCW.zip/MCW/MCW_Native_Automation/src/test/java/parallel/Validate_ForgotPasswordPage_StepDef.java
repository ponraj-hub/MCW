package parallel;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.ForgotPasswordPage;

import java.awt.*;

public class Validate_ForgotPasswordPage_StepDef extends CommonActions {
    ForgotPasswordPage forgot = new ForgotPasswordPage(DriverManager.getDriver());

    @Given("user verify forgot password link and click on forgot password link")
    public void user_verify_forgot_password_link_and_click_on_forgot_password_link() {
        forgot.userShouldVerifyForgotPasswordLinkAndClickOnForgotPasswordLink();
    }

    @When("user verify forgot password content")
    public void user_verify_forgot_password_content() {
        forgot.userShouldVerifyForgotPasswordContent();
    }

    @Then("user verify use my email text")
    public void user_verify_use_my_email_text() {
        forgot.userShouldVerifyUseMyEmailText();
    }

    @Then("user verify email text box")
    public void user_verify_email_text_box() throws AWTException {
       forgot.userShouldVerifyEmailTextBox();
    }

    @Then("user verify send code button")
    public void user_verify_send_code_button() {
        forgot.userShouldVerifySendCodeButton();
    }
}
