package parallel;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.HomePage;

public class Validate_HomePage_StepDef extends CommonActions {

    HomePage home = new HomePage(DriverManager.getDriver());

    @Given("user verify mister logo on home page")
    public void userVerifyMisterLogoOnHomePage() throws InterruptedException {
        home.userShouldVerifyMisterLogo();
    }

    @When("user verify hamburger menu and validate the page")
    public void userVerifyHamburgerMenuAndValidateThePage() {
        home.userShouldVerifyHamburgerMenuAndValidateThePage();
    }

    @Then("user verify location icon and validate the page as guest")
    public void userVerifyLocationIconAndValidateThePageAsGuest() {
        home.userShouldVerifyLocationIconAndValidateThePageAsGuest();
    }

    @Then("user verify the links inside the hamburger menu")
    public void userVerifyTheLinksInsideTheHamburgerMenu() {
        home.userShouldVerifyTheLinksInsideTheHamburgerMenu();
    }

    @Then("user verify location page popup notification")
    public void userVerifyLocationPagePopupNotification() {
        home.userShouldVerifyLocationPagePopupNotification();
    }

    @Then("user verify promo section in the home page")
    public void userVerifyPromoSectionInTheHomePage() {
        home.userShouldVerifyPromoSectionInTheHomePage();
    }

    @Then("user verify cta button and texts in the promo section")
    public void userVerifyCtaButtonAndTextsInThePromoSection() {
        home.userShouldVerifyCtaButtonAndTextsInThePromoSection();
    }

    @Then("user verify nearest location text and use my location link")
    public void userVerifyNearestLocationTextAndUseMyLocationLink() {
        home.userShouldVerifyNearestLocationTextAndUseMyLocationLink();
    }

    @Then("user verify uwc,wash,already member,locator buttons")
    public void userVerifyUwcWashAlreadyMemberLocatorButtons() {
        home.userShouldVerifyUwcWashAlreadyMemberLocatorButtons();
    }

    @Then("user verify home,buy,profile button on home page")
    public void userVerifyHomeBuyProfileButtonOnHomePage() {
        home.userShouldVerifyHomeBuyProfileButtonOnHomePage();
    }
}
