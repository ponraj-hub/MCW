package parallel;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.kidszone.BuyPage;

public class Validate_BuyPage_StepDef extends CommonActions {

    BuyPage buy = new BuyPage(DriverManager.getDriver());


    @Given("user click on buy page button")
    public void user_click_on_buy_page_button() {
          buy.userShouldClickOnBuyPageButton();
    }

    @When("user verify hamburger menu and location icon and all images of buy page")
    public void user_verify_hamburger_menu_and_location_icon_and_all_images_of_buy_page() {
       buy.userShouldVerifyHamburgerMenuAndLocationIconAndAllImagesOfBuyPage();
    }

    @Then("user verify title of the page")
    public void user_verify_title_of_the_page() {
        buy.userShouldVerifyTitleOfThePage();
    }

    @Then("user verify wash title and plan title")
    public void user_verify_wash_title_and_plan_title() {
    buy.userShouldVerifyWashTitleAndPlanTitle();
    }

    @Then("user verify description title")
    public void user_verify_description_title() {
     buy.userShouldVerifyDescriptionTitles();
    }
}
