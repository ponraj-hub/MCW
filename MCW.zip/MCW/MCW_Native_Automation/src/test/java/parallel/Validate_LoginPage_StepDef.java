package parallel;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.driverfactory.DriverManager;
import com.reusableMethods.CommonActions;

import pom.kidszone.LoginPage;

public class Validate_LoginPage_StepDef extends CommonActions {

	LoginPage login = new LoginPage(DriverManager.getDriver());
	public static final Logger logger = LoggerFactory.getLogger(Validate_LoginPage_StepDef.class);

	@When("user click on login link")
	public void user_click_on_login_link() {
		login.userShouldClickOnLoginLink();
	}

	@Then("user verify back arrow button and location icon")
	public void user_verify_back_arrow_button_and_location_icon() {
       login.userShouldVerifyBackArrowButtonAndLocationIcon();
	}

	@Then("user verify login header text")
	public void user_verify_login_header_text() {
      login.userShouldVerifyLoginHeaderText();
	}

	@Then("user verify mister image and login image")
	public void user_verify_mister_image_and_login_image() {
         login.userShouldVerifyMisterImageAndLoginImage();
	}

	@Then("user verify email and password search box")
	public void user_verify_email_and_password_search_box() {
		login.userShouldVerifyEmailAndPasswordSearchBox();
	}

	@Then("user verify remember me text and remember me check box")
	public void user_verify_remember_me_text_and_remember_me_check_box() {
		login.userShouldVerifyRememberMeTextAndRememberMeCheckBox();
	}

	@Then("user verify forgot password link")
	public void user_verify_forgot_password_link() {
        login.userShouldVerifyForgotPasswordLink();
	}

	@Then("user verify don't have an account text")
	public void user_verify_don_t_have_an_account_text() {
         login.userShouldVerifyDontHaveAnAccountText();
	}

	@Then("user verify create one link")
	public void user_verify_create_one_link() {
         login.userShouldVerifyCreateOneLink();
	}

	@And("user verify remember me checkbox working")
	public void userVerifyRememberMeCheckboxWorking() {
		login.userShouldVerifyRememberMeCheckBox();
	}
}
