package eyesmanager;

import org.openqa.selenium.WebDriver;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.StdoutLogHandler;
import com.applitools.eyes.appium.Eyes;
import com.applitools.eyes.config.Configuration;

import io.cucumber.java.Scenario;

public class EyesSetup {
	
	public static Eyes eyes;
	
	// UltraFast Grid Runner Variables//

	private final String appName = "axisweb";
	private final String batchName = "axis-app-tests";
	String myEyesServer = "https://eyesapi.applitools.com/";
	private String apiKey = "VJ1d3kQtEHQ108TPMSgXWakGsYYZmC75MkuwgPLCy7HWQ110";
	private Configuration suiteConfig;
	

	public Eyes getEyes(WebDriver driver, Scenario scenario) {
		eyes = new Eyes();
		eyes.setApiKey(apiKey);
		eyes.setServerUrl(myEyesServer);
		eyes.setBatch(new BatchInfo(batchName));
		eyes.open(driver, appName, scenario.getName());
//		eyes.setLogHandler(new StdoutLogHandler(true));
		return eyes;
	}

}
