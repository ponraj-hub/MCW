
# Getting Started
To Guide users to configure the framework code up and running on your own system. In this section you can talk about:
1.	Installation process
2.	Test Data
		

#Installation process
 
 Get the latest code from <a href="https://dev.azure.com/baker-taylorAxis360Suite/ReactNative/_git/Reimagine_Axis360App_Automation">ADO</a> from <b> Release</b> branch and export the project to eclipse/ intelliJ . Once upload project do MVN update project. 
<h1> MobileDevice To Add </h1>
  Go to inside of <b><i> src/test/resources/com/browserstack/run_parallel_test </i></b> folder open the parallel.conf.json file and add the new device and OS version make sure the device should be available in browserStack. 
<h1> Parallel Thread To Add </h1>
  Go to pom.xml file check the thread count if its count is 1 single session will open and run. Based on your convenience you can mention the count and run . 
 <h1>MVN Execution Commands</h1> 
  If you are running in Browserstack you have to set the System EnV Browserstack username , Browserstack Accesskey and Browserstack Appid.
  <br> For MAC,
  </br> export BROWSERSTACK_USERNAME= 
  </br>export BROWSERSTACK_ACCESS_KEY=
  </br>export BROWSERSTACK_APP_ID=
  
  For Windows use 'set' instead of export . You have to upload the (apk ,ipa) file in Browserstack then you will get the app id.
  
  To run the test cases use the below MVN commands 
  
  mvn clean test -Dplatform=<iOS/ Android> -Dbuild=<build#> -DplatformVersion=<Device version> -DdeviceName=<Device name> -DdeviceIndex=< Device index>
  
  <b>Note</b> - For device index you will get it from parallel.conf.json file 
  
#Test Data 

 Before you run the test case you have to set the test data. Please refer the xls to configure the data <a href="https://bakertaylorllc.sharepoint.com/:x:/s/Axis360Photon/EZ2IRxc1zINJjutY2XQINpABlBVzFnWHhcF1hU0qhiGixA?e=2MmwHO">Test Data</a>